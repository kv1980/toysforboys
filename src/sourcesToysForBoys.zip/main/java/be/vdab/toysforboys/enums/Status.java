package be.vdab.toysforboys.enums;

public enum Status {
	PROCESSING, WAITING, SHIPPED, DISPUTED, RESOLVED, CANCELLED
}
